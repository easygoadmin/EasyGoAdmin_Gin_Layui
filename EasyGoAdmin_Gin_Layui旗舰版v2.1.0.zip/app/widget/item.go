// +----------------------------------------------------------------------
// | 版权和免责声明:
// | 本团队对该软件框架产品拥有知识产权（包括但不限于商标权、专利权、著作权、商业秘密等）
// | 均受到相关法律法规的保护，任何个人、组织和单位不得在未经本团队书面授权的情况下对所授权
// | 软件框架产品本身申请相关的知识产权，禁止用于任何违法、侵害他人合法权益等恶意的行为，禁
// | 止用于任何违反我国法律法规的一切项目研发，任何个人、组织和单位用于项目研发而产生的任何
// | 意外、疏忽、合约毁坏、诽谤、版权或知识产权侵犯及其造成的损失 (包括但不限于直接、间接、
// | 附带或衍生的损失等)，本团队不承担任何法律责任，本软件框架禁止任何单位和个人、组织用于
// | 任何违法、侵害他人合法利益等恶意的行为，如有发现违规、违法的犯罪行为，本团队将无条件配
// | 合公安机关调查取证同时保留一切以法律手段起诉的权利，本软件框架只能用于公司和个人内部的
// | 法律所允许的合法合规的软件产品研发，详细声明内容请阅读《框架免责声明》附件；
// +----------------------------------------------------------------------

/**
 * 站点选择组件
 * @author 半城风雨
 * @since 2021/7/19
 * @File : icon
 */
package widget

import (
	"easygoadmin/app/model"
	"easygoadmin/app/service"
	"easygoadmin/utils"
	"easygoadmin/utils/gconv"
	"html/template"
	"reflect"
)

func Item(itemId int, cateId int, limit int) template.HTML {
	// 初始化组件
	var dataList = make([]map[string]interface{}, 0)

	// 站点
	var itemMap = make(map[string]interface{}, 0)
	itemMap["tname"] = "站点"
	itemMap["code"] = "item"
	itemMap["selected"] = itemId

	var itemList = make([]map[string]string, 0)
	// 站点数据源
	itemData := make([]model.Item, 0)
	utils.XormDb.Where("status=1 and mark=1").Cols("id,name").Find(&itemData)
	for _, v := range itemData {
		item := map[string]string{}
		item["id"] = gconv.String(v.Id)
		item["name"] = v.Name
		itemList = append(itemList, item)
	}
	itemMap["list"] = itemList
	dataList = append(dataList, itemMap)

	// 栏目
	if limit >= 2 {
		var cateMap = make(map[string]interface{}, 0)
		cateMap["tname"] = "栏目"
		cateMap["code"] = "cate"
		cateMap["selected"] = cateId
		// 获取栏目列表
		data, _ := service.ItemCate.GetCateTreeList(itemId, 0)
		// 数据源转换
		cateList := service.ItemCate.MakeList(data)
		cateMap["list"] = cateList
		dataList = append(dataList, cateMap)
	}

	// 拼接HTML
	html := ``

	// 遍历组件源
	for _, val := range dataList {
		html += `<div class="layui-input-inline">
		<select name="` + gconv.String(val["code"]) + `Id" id="` + gconv.String(val["code"]) + `Id" lay-filter="` + gconv.String(val["code"]) + `Id" lay-search="">
			<option value="">【请选择` + gconv.String(val["tname"]) + `】</option>`

		// 下拉选择项
		if reflect.TypeOf(val["list"]).String() == "[]map[string]string" {
			for _, v := range val["list"].([]map[string]string) {
				html += `<option value="` + gconv.String(v["id"]) + `" `
				if gconv.String(v["id"]) == gconv.String(val["selected"]) {
					html += `selected=""`
				}
				html += `>` + gconv.String(v["name"]) + `</option>`
			}
		}
		html += `</select>
	</div>`
	}

	// JS脚本
	html += `<script type="text/javascript">
	layui.use(['form'],function(){

		// 声明变量
		var layer = layui.layer
				,form = layui.form
				,$ = layui.$;

		// 选择站点
		form.on('select(itemId)',function(data){
			var id = data.value;
			console.log("站点ID:"+id);
			var select = data.othis;
			if (select[0]) {
				if (id > 0) {
					$.get("/itemcate/getCateTreeList?itemId=" + id, function(data){
						if (data.code==0) {
							var str = "";
							$.each(data.data, function(i,item){
								str += "<option value=\"" + item.id + "\" >" + item.name + "</option>";
							});
							$("#cateId").html('<option value="">【请选择栏目】</option>' + str);
							form.render('select');
						}else{
							$("#cateId").html('');
							form.render('select');
							layer.msg(data.msg,{ icon: 5 });
							return false;
						}
					}, 'json');
				} else {

				}
			}
		});

		// 选择栏目
		form.on("select(cateId)",function(data){
			var id = data.value;
			console.log("栏目ID:"+id);
		});

	});
</script>`

	return template.HTML(html)
}
