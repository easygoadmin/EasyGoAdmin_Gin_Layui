// +----------------------------------------------------------------------
// | 版权和免责声明:
// | 本团队对该软件框架产品拥有知识产权（包括但不限于商标权、专利权、著作权、商业秘密等）
// | 均受到相关法律法规的保护，任何个人、组织和单位不得在未经本团队书面授权的情况下对所授权
// | 软件框架产品本身申请相关的知识产权，禁止用于任何违法、侵害他人合法权益等恶意的行为，禁
// | 止用于任何违反我国法律法规的一切项目研发，任何个人、组织和单位用于项目研发而产生的任何
// | 意外、疏忽、合约毁坏、诽谤、版权或知识产权侵犯及其造成的损失 (包括但不限于直接、间接、
// | 附带或衍生的损失等)，本团队不承担任何法律责任，本软件框架禁止任何单位和个人、组织用于
// | 任何违法、侵害他人合法利益等恶意的行为，如有发现违规、违法的犯罪行为，本团队将无条件配
// | 合公安机关调查取证同时保留一切以法律手段起诉的权利，本软件框架只能用于公司和个人内部的
// | 法律所允许的合法合规的软件产品研发，详细声明内容请阅读《框架免责声明》附件；
// +----------------------------------------------------------------------

/**
 * 穿梭组件
 * @author 半城风雨
 * @since 2021/7/19
 * @File : transfer
 */
package widget

import (
	"easygoadmin/utils/gconv"
	"encoding/json"
	"html/template"
	"reflect"
	"strings"
)

func Transfer(param string, data interface{}, value interface{}) template.HTML {
	// 参数分析
	item := strings.Split(param, "|")
	// 组件名称
	tsfName := item[0]
	// 是否显示搜索
	tsfSearch := item[1]
	// 组件标题
	tsfTitle := strings.Split(item[2], ",")
	//// 组件显示名
	//tsfText := item[3]
	//// 组件显示值
	//tsfValue := item[4]
	// 组件宽度
	tsfWidth := 220
	// 组件高度
	tsfHeight := 350
	if len(item) >= 6 && item[5] != "" {
		subItem := strings.Split(item[5], "x")
		// 宽度
		tsfWidth = gconv.Int(subItem[0])
		tsfHeight = gconv.Int(subItem[1])
	}

	// 绑定值
	if reflect.ValueOf(value).Kind() == reflect.Slice {
		// 数组为空时初始化对象
		if len(value.([]interface{})) == 0 {
			value = make([]interface{}, 0)
		}
	} else if reflect.ValueOf(value).Kind() == reflect.String {
		// 字符串为空时赋予空置
		if gconv.String(value) == "" {
			value = []int{}
		}
	}

	// 数据处理
	list := make([]map[string]string, 0)
	if reflect.ValueOf(data).Kind() == reflect.String {
		// 字符串数据源处理
		dList := strings.Split(gconv.String(data), ",")
		for _, val := range dList {
			v := strings.Split(val, "=")
			obj := make(map[string]string)
			obj["value"] = v[0]
			obj["title"] = v[1]
			list = append(list, obj)
		}
	} else if reflect.ValueOf(data).Kind() == reflect.Map {
		// Map

	} else if reflect.ValueOf(data).Kind() == reflect.Slice {
		// 数组数据源
		for _, val := range data.([]map[string]string) {
			for k, v := range val {
				obj := make(map[string]string)
				obj["value"] = k
				obj["title"] = v
				list = append(list, obj)
			}
		}
	}

	// 数据源列表转字符串
	mjson, _ := json.Marshal(list)

	// 组件HTML
	html := ``
	html += `<div id="` + tsfName + `" class="demo-transfer"></div>
<script>
	layui.use(['transfer'], function(){
		var transfer = layui.transfer

		//定义标题及数据源
		transfer.render({
			elem: "#` + tsfName + `"
			,title: ['` + tsfTitle[0] + `', '` + tsfTitle[1] + `']  //自定义标题
			,showSearch: ` + tsfSearch + `
			,data: ` + string(mjson) + `
            ,id: '` + tsfName + `' //定义唯一索引
			,width: ` + gconv.String(tsfWidth) + ` //定义宽度
			,height: ` + gconv.String(tsfHeight) + ` //定义高度
			,value: ` + gconv.String(value) + `
			,onchange: function(obj, index){
			}
		})

	});
</script>`
	return template.HTML(html)
}
