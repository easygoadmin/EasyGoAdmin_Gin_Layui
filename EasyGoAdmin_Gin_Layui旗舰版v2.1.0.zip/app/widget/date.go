// +----------------------------------------------------------------------
// | 版权和免责声明:
// | 本团队对该软件框架产品拥有知识产权（包括但不限于商标权、专利权、著作权、商业秘密等）
// | 均受到相关法律法规的保护，任何个人、组织和单位不得在未经本团队书面授权的情况下对所授权
// | 软件框架产品本身申请相关的知识产权，禁止用于任何违法、侵害他人合法权益等恶意的行为，禁
// | 止用于任何违反我国法律法规的一切项目研发，任何个人、组织和单位用于项目研发而产生的任何
// | 意外、疏忽、合约毁坏、诽谤、版权或知识产权侵犯及其造成的损失 (包括但不限于直接、间接、
// | 附带或衍生的损失等)，本团队不承担任何法律责任，本软件框架禁止任何单位和个人、组织用于
// | 任何违法、侵害他人合法利益等恶意的行为，如有发现违规、违法的犯罪行为，本团队将无条件配
// | 合公安机关调查取证同时保留一切以法律手段起诉的权利，本软件框架只能用于公司和个人内部的
// | 法律所允许的合法合规的软件产品研发，详细声明内容请阅读《框架免责声明》附件；
// +----------------------------------------------------------------------

/**
 * 日期选择组件
 * @author 半城风雨
 * @since 2021/7/26
 * @File : date
 */
package widget

import (
	"easygoadmin/utils/gconv"
	"html/template"
	"strings"
	"time"
)

func Date(param string, value interface{}) template.HTML {
	// 组件参数分析
	arr := strings.Split(param, "|")
	// 组件标识
	dateName := arr[0]
	// 是否必填
	isRequire := arr[1]
	// 下拉提示
	dateTips := arr[2]
	// 日期类型
	dateType := arr[3]
	// 非必填验证
	if isRequire != "1" {
		dateType = ""
	}
	// 日期间隔
	dateSpan := ""
	if len(arr) >= 5 {
		dateSpan = arr[4]

	}
	// 日期间隔符号
	dateStr := ""
	if len(arr) >= 6 {
		dateStr = arr[5]
	}

	// 组件的值
	dateValue := ""
	// 日期组件时间格式
	dateFormat := "2006-01-02 15:04:05"
	if dateType == "date" {
		dateFormat = "2006-01-02"
	}
	if value != nil {
		dateValue = time.Unix(gconv.Int64(value), 0).Format(dateFormat)
	}

	html := `<input name="` + dateName + `" id="` + dateName + `" value="` + dateValue + `" lay-verify="` + dateType + `" placeholder="请选择` + dateTips + `" autocomplete="off" class="layui-input date-icon" type="text">
<script>
    layui.use(['func'], function () {
        var func = layui.func;

        // 初始化日期
        func.initDate(['` + dateName + `|` + dateType + `|` + dateSpan + `|` + dateStr + `'], function (value, date) {
            console.log("当前选择日期:" + value);
            console.log("日期详细信息：" + JSON.stringify(date));
        });
    });
</script>`
	return template.HTML(html)
}
