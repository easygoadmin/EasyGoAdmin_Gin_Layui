// +----------------------------------------------------------------------
// | 版权和免责声明:
// | 本团队对该软件框架产品拥有知识产权（包括但不限于商标权、专利权、著作权、商业秘密等）
// | 均受到相关法律法规的保护，任何个人、组织和单位不得在未经本团队书面授权的情况下对所授权
// | 软件框架产品本身申请相关的知识产权，禁止用于任何违法、侵害他人合法权益等恶意的行为，禁
// | 止用于任何违反我国法律法规的一切项目研发，任何个人、组织和单位用于项目研发而产生的任何
// | 意外、疏忽、合约毁坏、诽谤、版权或知识产权侵犯及其造成的损失 (包括但不限于直接、间接、
// | 附带或衍生的损失等)，本团队不承担任何法律责任，本软件框架禁止任何单位和个人、组织用于
// | 任何违法、侵害他人合法利益等恶意的行为，如有发现违规、违法的犯罪行为，本团队将无条件配
// | 合公安机关调查取证同时保留一切以法律手段起诉的权利，本软件框架只能用于公司和个人内部的
// | 法律所允许的合法合规的软件产品研发，详细声明内容请阅读《框架免责声明》附件；
// +----------------------------------------------------------------------

/**
 * 下拉选择组件
 * @author 半城风雨
 * @since 2021/7/26
 * @File : select
 */
package widget

import (
	"easygoadmin/utils/gconv"
	"easygoadmin/utils/gstr"
	"html/template"
	"reflect"
	"strings"
)

func Select(param string, data interface{}, checkedId interface{}) template.HTML {
	// 组件参数分析
	arr := strings.Split(param, "|")
	// 组件标识
	selName := arr[0]
	// 是否必填
	isRequire := arr[1]
	// 下拉提示
	selTips := arr[2]
	//// 下拉标题
	//selTitle := ""
	//if len(arr) >= 4 {
	//	selTitle = arr[3]
	//}
	//// 下拉值
	//selValue := ""
	//if len(arr) >= 5 {
	//	selValue = arr[4]
	//}

	// 开始
	html := `<select name="` + selName + `" id="` + selName + `" `
	// 是否必填
	if gconv.Int(isRequire) == 1 {
		html += `lay-verify="required"`
	}
	html += ` lay-search="" lay-filter="` + selName + `">`

	// 下拉提示
	html += `<option value="">【请选择` + selTips + `】</option>`

	// 数据处理
	if reflect.ValueOf(data).Kind() == reflect.String {
		if reflect.TypeOf(data).String() == "string" {
			item := gstr.Split(data.(string), ",")
			for _, v := range item {
				subItem := gstr.Split(v, "=")
				html += `<option value="` + gconv.String(subItem[0]) + `" `
				if subItem[0] == gconv.String(checkedId) {
					html += `selected=""`
				}
				html += `>` + subItem[1] + `</option>`
			}
		}
	} else if reflect.ValueOf(data).Kind() == reflect.Map {
		if reflect.TypeOf(data).String() == "map[string]string" {
			for k, v := range data.(map[string]string) {
				html += `<option value="` + gconv.String(k) + `" `
				if k == gconv.String(checkedId) {
					html += `selected=""`
				}
				html += `>` + v + `</option>`
			}
		} else if reflect.TypeOf(data).String() == "map[int]string" {
			for k, v := range data.(map[int]string) {
				html += `<option value="` + gconv.String(k) + `" `
				if k == gconv.Int(checkedId) {
					html += `selected=""`
				}
				html += `>` + v + `</option>`
			}
		}
	} else if reflect.ValueOf(data).Kind() == reflect.Slice {
		if reflect.TypeOf(data).String() == "map[string]string" {
			for _, item := range data.([]map[string]string) {
				for k, v := range item {
					html += `<option value="` + gconv.String(k) + `"`
					if k == gconv.String(checkedId) {
						html += `selected=""`
					}
					html += `>` + v + `</option>`
				}
			}
		} else if reflect.TypeOf(data).String() == "map[int]string" {
			for _, item := range data.([]map[int]string) {
				for k, v := range item {
					html += `<option value="` + gconv.String(k) + `"`
					if k == gconv.Int(checkedId) {
						html += `selected=""`
					}
					html += `>` + v + `</option>`
				}
			}
		}
	}

	// 结束
	html += `</select>`

	return template.HTML(html)
}
