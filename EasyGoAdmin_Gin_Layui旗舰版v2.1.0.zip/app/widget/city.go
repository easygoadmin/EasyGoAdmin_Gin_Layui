// +----------------------------------------------------------------------
// | 版权和免责声明:
// | 本团队对该软件框架产品拥有知识产权（包括但不限于商标权、专利权、著作权、商业秘密等）
// | 均受到相关法律法规的保护，任何个人、组织和单位不得在未经本团队书面授权的情况下对所授权
// | 软件框架产品本身申请相关的知识产权，禁止用于任何违法、侵害他人合法权益等恶意的行为，禁
// | 止用于任何违反我国法律法规的一切项目研发，任何个人、组织和单位用于项目研发而产生的任何
// | 意外、疏忽、合约毁坏、诽谤、版权或知识产权侵犯及其造成的损失 (包括但不限于直接、间接、
// | 附带或衍生的损失等)，本团队不承担任何法律责任，本软件框架禁止任何单位和个人、组织用于
// | 任何违法、侵害他人合法利益等恶意的行为，如有发现违规、违法的犯罪行为，本团队将无条件配
// | 合公安机关调查取证同时保留一切以法律手段起诉的权利，本软件框架只能用于公司和个人内部的
// | 法律所允许的合法合规的软件产品研发，详细声明内容请阅读《框架免责声明》附件；
// +----------------------------------------------------------------------

/**
 * 城市选择组件
 * @author 半城风雨
 * @since 2021/7/27
 * @File : city
 */
package widget

import (
	"easygoadmin/app/model"
	"easygoadmin/utils"
	"easygoadmin/utils/gconv"
	"html/template"
	"reflect"
)

func City(cityCode interface{}, limit int, isRequire int) template.HTML {
	// 初始化组件
	var cityList = make([]map[string]interface{}, 0)

	// 省份
	var provinceMap = make(map[string]interface{}, 0)
	provinceMap["cname"] = "省"
	provinceMap["code"] = "province"
	provinceMap["selected"] = ""
	cityList = append(cityList, provinceMap)

	// 城市
	var cityMap = make(map[string]interface{}, 0)
	cityMap["cname"] = "市"
	cityMap["code"] = "city"
	cityMap["selected"] = ""
	cityList = append(cityList, cityMap)

	// 县区
	var districtMap = make(map[string]interface{}, 0)
	districtMap["cname"] = "县区"
	districtMap["code"] = "district"
	districtMap["selected"] = ""
	cityList = append(cityList, districtMap)

	// 查询城市信息

	var info model.City
	has, err := utils.XormDb.Where("citycode=?", cityCode).Get(&info)
	// 上级ID
	pid := 0
	// 城市等级
	level := 0
	if err == nil && has {
		pid = info.Pid
		level = info.Level - 1
	}

	// 加载数据源
	for {
		// 获取子级城市
		childList := make([]model.City, 0)
		utils.XormDb.Where("pid=? and mark=1", pid).Find(&childList)
		var dataList = make([]map[string]string, 0)
		for _, v := range childList {
			item := map[string]string{}
			item["id"] = v.Citycode
			item["name"] = v.Name
			dataList = append(dataList, item)
		}
		// 设置数据源
		if err == nil && has {
			cityList[level]["selected"] = info.Citycode
		}
		cityList[level]["list"] = dataList

		// 业务处理
		if pid > 0 {
			info = model.City{}
			has2, err2 := utils.XormDb.Id(pid).Get(&info)
			if err2 != nil || !has2 {
				// 直接赋值-1，跳出循环
				level = -1
				break
			}
			pid = info.Pid
		}
		// 计数器-1
		level--
		if level < 0 {
			// 跳出循环
			break
		}
	}

	// 拼接HTML
	html := ``
	// 数组切片
	cityList = cityList[:limit]
	// 遍历组件源
	for _, val := range cityList {
		html += `<div class="layui-input-inline" style="width:170px;">
		<select name="` + gconv.String(val["code"]) + `Code" id="` + gconv.String(val["code"]) + `Code" lay-filter="` + gconv.String(val["code"]) + `Code" lay-search="" `
		// 是否必填
		if gconv.Int(isRequire) == 1 {
			html += `lay-verify="required"`
		}
		html += `>
			<option value="">【请选择` + gconv.String(val["cname"]) + `】</option>`

		// 下拉数据源
		if val["list"] != nil && reflect.TypeOf(val["list"]).String() == "[]map[string]string" {
			for _, v := range val["list"].([]map[string]string) {
				html += `<option value="` + gconv.String(v["id"]) + `" `
				if gconv.String(v["id"]) == gconv.String(val["selected"]) {
					html += `selected=""`
				}
				html += `>` + gconv.String(v["name"]) + `</option>`
			}
		}

		html += `</select>
	</div>`
	}

	// JS拼接
	html += `<script type="text/javascript">
layui.use(['form'],function(){

	// 声明变量
	var form = layui.form,
		$ = layui.$;

	// 选择省份
	form.on('select(provinceCode)',function(data){
		var citycode = data.value;
		console.log("省份ID:"+citycode);
		var select = data.othis;
		if (select[0] && citycode != "") {
			$.post("/city/getChilds", { 'citycode':citycode }, function(data){
				if (data.code==0) {
					var str = "";
					$.each(data.data, function(i,item){
						str += "<option value=\"" + item.citycode + "\" >" + item.name + "</option>";
					});
					$("#cityCode").html('<option value="">【请选择市】</option>' + str);
					$("#districtCode").html('<option value="">【请选择县/区】</option>');
					form.render('select');
				}else{
					layer.msg(data.msg,{ icon: 5 });
					$("#cityCode").html('<option value="">【请选择市】</option>');
					$("#districtCode").html('<option value="">【请选择县/区】</option>');
					form.render('select');
					return false;
				}
			}, 'json');
		} else {
			$("#cityCode").html('<option value="">【请选择市】</option>');
			$("#districtCode").html('<option value="">【请选择县/区】</option>');
			form.render('select');
			return false;
		}
	});
	
	// 选择城市
	form.on('select(cityCode)',function(data){
		var citycode = data.value;
		console.log("城市ID:"+citycode);
		var select = data.othis;
		if (select[0] && citycode != "") {
			$.post("/city/getChilds", { 'citycode':citycode }, function(data){
				if (data.code==0) {
					var str = "";
					$.each(data.data, function(i,item){
						str += "<option value=\"" + item.citycode + "\" >" + item.name + "</option>";
					});
					$("#districtCode").html('<option value="">【请选择县/区】</option>' + str);
					form.render('select');
				} else {
					layer.msg(data.msg,{ icon: 5 });
					$("#districtCode").html('<option value="">【请选择县/区】</option>');
					form.render('select');
					return false;
				}
			}, 'json');
		} else {
			$("#districtCode").html('<option value="">【请选择县/区】</option>');
			form.render('select');
			return false;
		}
	});
	
	// 选择县区
	form.on("select(districtCode)",function(data){
		var citycode = data.value;
		console.log("县区ID:"+citycode);
	});
	
});
</script>`

	return template.HTML(html)
}
